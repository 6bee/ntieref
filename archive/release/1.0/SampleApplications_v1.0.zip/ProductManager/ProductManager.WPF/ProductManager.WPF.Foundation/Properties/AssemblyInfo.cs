﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ProductManager.WPF.Foundation")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Trivadis")]
[assembly: AssemblyProduct("ProductManager.WPF.Foundation")]
[assembly: AssemblyCopyright("Copyright © Trivadis 2011")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: CLSCompliant(true)]
[assembly: ComVisible(false)]
[assembly: Guid("29f89276-1f4e-40e7-b5f0-f907158f2490")]


[assembly: AssemblyVersion("1.0.0.400")]
[assembly: AssemblyFileVersion("1.0.0.400")]
