﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProductManager.Common.Domain.Model.ProductManager
{
    public enum ProductColorFilter
    {
        NoFilter,
        Black,
        Blue,
        Green,
        Grey,
        Red,
        Silver,
        White,
        Yellow
    }
}
